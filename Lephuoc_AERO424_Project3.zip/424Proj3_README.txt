To verify Q1 and Q2 (30 degree cross-track slewing), run the Proj3_CrossTrackSlewVerification.m file
To verify Q3, Q4, and Q5, run the ProjectAssignment3.m file

A_LVLH.m - calculates DCM from ECI frame to LVLH frame
A_q.m - calculates DCM corresponding to a given quaternion
DisturbanceTorques.m - calculates total disturbance torques given a quaternion, a position vector in the ECI frame, and a velocity vector in the ECI frame
ECEF_ECI_Matrix - calculates DCM from ECI to ECEF frames
EulerMatrix - calculates 3-2-1 Euler transformation
julian_date - calculates Julian date for use in calculating ECEF frame
readCSV - processing rv_vec_HST.csv

Sorry for the mess!